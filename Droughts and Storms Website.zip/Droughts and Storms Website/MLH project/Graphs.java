import java.util.*;
import java.io.*;
/**
 * Write a description of class Graphs here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Graphs
{
    private Canvas canvas;
    private Scanner scan;//temperature scanner
    private Scanner scanner;//precipitatoin scanner
    private Scanner sc;//psdi drought scanner
    private HashMap<String,Double> hmap;//temperature map
    private HashMap<String,Double> hm;//precipitation map
    private HashMap<String,Double> map;//drought map

    /**
     * Constructor for objects of class Graphs
     */
    public Graphs()throws FileNotFoundException
    {
        File file = new File("Annual Temperature Over the years.txt");
        File fl = new File("Average Precipitation over the years.txt");
        File fil = new File("PSDI drought index.txt");
        scan = new Scanner(file);
        scanner = new Scanner(fl);
        sc = new Scanner(fil);
    }
    
    public void populate()
    {
        scan.nextLine();
        while(scan.hasNextLine())
        {
            scan.nextLine().split("    ");
            String year = scan.next();
            double yearVal;
            
            
        }
        scanner.nextLine();
        sc.nextLine();
        
    }
    
    public void graphs()
    {
        canvas = new Canvas("Water Consumption over time in California",800,800);

    }
}
