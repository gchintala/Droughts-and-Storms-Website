import java.util.*;
import java.io.*;
/**
 * Write a description of class Graphs here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Graphs
{
    private Canvas canvas;
    private Scanner scan;//temperature scanner
    private Scanner scanner;//precipitatoin scanner
    private Scanner sc;//psdi drought scanner
    private HashMap<String,String> hmap;//temperature map
    private HashMap<String,String> hm;//precipitation map
    private HashMap<String,String> map;//drought map

    /**
     * Constructor for objects of class Graphs
     */
    public Graphs()throws FileNotFoundException
    {
        File file = new File("Annual Temperature Over the years.txt");
        //File fl = new File("Average Precipitation over the years.txt");
        //File fil = new File("PSDI drought index.txt");
        scan = new Scanner(file);
        //scanner = new Scanner(fl);
        //sc = new Scanner(fil);
        populate();
    }
    
    public void populate()
    {
        scan.nextLine();
        while(scan.hasNextLine())
        {
            String[] words = scan.nextLine().split("    ");
            hmap.put(wo`rds[0],words[1]);
        }
        System.out.println(hmap);
        //scanner.nextLine();
        //sc.nextLine();
        
    }
    
    public void graphs()
    {
        canvas = new Canvas("Water Consumption over time in California",800,800);

    }
}
